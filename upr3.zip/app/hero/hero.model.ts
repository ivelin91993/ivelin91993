export interface Hero {
  [x: string]: any;
  name: string;
  universe: any;
  powers: any[];
}
