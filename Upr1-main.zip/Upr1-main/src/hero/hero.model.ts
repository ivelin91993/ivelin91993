export interface Hero {
    name: string;
    universe: string;
    powers: string[];
}